/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/sortsForTheDayJson.json';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import NumberClass from 'Util/NumberClass';

class SortsForTheDay extends Component {

	constructor(props) {
		super(props);
		this.state = { 
					   label: [],
					   value: [],
					   sorts: 0,
					   sortsPercent: 0,
					   isLoading:true
					 };
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let query = `query GetInductsForLastHour($startTime: Long!, $xMins: Int, $goalVal: Int, $duration: String!, $sorterid: String!) {
						    	getUSSDataForLastXMins(startTime: $startTime, xMins: $xMins, goalVal: $goalVal, duration:$duration, sorterid: $sorterid) {
						  	  		sorts sortsPercent  
						  			inductsLastXDays{ sorts date }
						  }
					}`;
		
		let startTime = 201903231431;//dateFormat(new Date(), "yyyymmddHHMM");
		let xMins = 1440;
		let goalVal = this.props.goal;
		let duration = "5-days";
		let sorterid = this.props.sorterid;

		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, xMins, goalVal, duration, sorterid }
			})
		})
		.then(r => r.json())
		.then(data => { 
			//console.log("XXXXXXXXXXXXSortsForTheDayXXXXXXXXXXXXXX");
			//console.log(data);
			//console.log("XXXXXXXXXXXXSortsForTheDayXXXXXXXXXXXXXX");
			let label = data.data.getUSSDataForLastXMins.inductsLastXDays == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXDays.map(list => list.date.substring(6,8)+"/"+list.date.substring(4, 6)+"/"+list.date.substring(0, 4) );
		    let value = data.data.getUSSDataForLastXMins.inductsLastXDays == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXDays.map(list => list.sorts);
		    console.log(label);
		    this.setState({ label: label,
				   			value: value,
				   			sorts: data.data.getUSSDataForLastXMins.sorts,
				   			sortsPercent: data.data.getUSSDataForLastXMins.sortsPercent,
						    isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ label: [],
				   			value: [],
				   			sorts: 0,
				   			sortsPercent: 0,
						    isLoading:false
						 }); 
		});
	}

	render() {
				
		const { isColorBlind } = this.props;
			
		var guageBGColor = json.container[0].leftLayout.components[0].options.guageBGColor
		var fontColor = json.container[0].rightLayout.components[0].componentTop.options.goalFontColor
		var graphBGColor = json.container[0].rightLayout.components[0].componentBottom.options.chartBGColor
		
		//Check For color blind and change the color
		if(isColorBlind) {
			guageBGColor = '#87871f'
			fontColor = '#1E90FF'
			graphBGColor = '#87871f'
		}
	
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={json.title}
										fullBlock > 
					</RctCollapsibleCard>);
			} else {
				return (
						<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
											heading={json.title}
											fullBlock >
							<div className="clearfix">
			                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
			                    <div className="d-flex">
			                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
									<div className="circulararea">
			                        	<CircularProgressbar percentage={this.state.sortsPercent}
			                        						 text={`${this.state.sortsPercent}%`}
			                        						 backgroundPadding={10}
			                        						 styles={{ path: { stroke:  guageBGColor, strokeLinecap: 'butt' },
			                        							 	   text: { fill: '#121212', fontSize: '25px', textAnchor: "middle", dominantBaseline: "middle"},
			                        							 	   trail: { stroke: '#d7d7d7' },
			                        							 	   background: { fill: '#fffff' }
			                        						 }}
			                        	/>
										</div>
			                        </div>
			                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
			                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
			                                <span className="counter-point">
												<strong>&nbsp; <NumberClass  number={this.state.sorts} />  / &nbsp;
													<span style={{color: fontColor}}><NumberClass  number={this.props.goal} /></span></strong>
			                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
			                                </span>
			                            </div>
			                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
										<div className="lastdays-text">{json.container[0].rightLayout.components[0].componentBottom.options.chartLabel}</div>
			                                <TinyAreaChart chartdata={this.state.value}
					                     		   		   labels={this.state.label}
			                                    		   backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
			                                    		   borderColor={graphBGColor}
			                                    		   lineTension="0"
			                                    		   height={130}
			                                    		   gradient />
			                            </div>
			                        </div>
			                    </div>
			                </div>
			            </div>
			        </RctCollapsibleCard>
				);
			}
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(SortsForTheDay));